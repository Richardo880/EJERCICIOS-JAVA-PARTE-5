
import java.awt.AWTException;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.ImageIcon;


public class trayApp{
    protected int Num1 = 0,Num2 = 0,Resul = 0;
    static TrayIcon trayIcon;
    static SystemTray tray;
    Ejercicio3 ej3 = new Ejercicio3();
    public trayApp() {
        if(!SystemTray.isSupported()){
            System.exit(0);
        }
        
        PopupMenu menu = new PopupMenu();
        trayIcon = new TrayIcon(crearIcono("E3/calculadora.png","Icono"));
        trayIcon.setImageAutoSize(true);
        tray = SystemTray.getSystemTray();
        
        trayIcon.setToolTip("Ejercicio3");
        
        MenuItem abrir = new MenuItem("Abrir");
        MenuItem salir = new MenuItem("Salir");
        
        menu.add(abrir);
        menu.addSeparator();
        menu.add(salir);
        
        trayIcon.setPopupMenu(menu);
        
        abrir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                ej3.setVisible(true);
                if(Num1 != 0)
                    ej3.Num1.setText(String.valueOf(Num1));
                if(Num2 != 0)
                    ej3.Num2.setText(String.valueOf(Num2));
                if(Resul != 0){
                    ej3.btnCal.setEnabled(true);
                    ej3.sumaResultado.setText(String.valueOf(Resul));
                    ej3.labelResul.setVisible(true);
                    ej3.sumaResultado.setVisible(true);
                }
                tray.remove(trayIcon);
            }
        });
        
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                tray.remove(trayIcon);
                System.exit(0);
            }
        });
        
        try {
            tray.add(trayIcon);
        } catch (AWTException ex) {
        }
    }
    
    protected static Image crearIcono(String dir, String desc){
        URL imageURL = trayApp.class.getResource(dir);
        return(new ImageIcon(imageURL,desc)).getImage();
    }
}
