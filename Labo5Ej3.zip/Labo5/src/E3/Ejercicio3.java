
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class Ejercicio3 extends javax.swing.JFrame {
    public Ejercicio3() {
        initComponents();
        labelResul.setVisible(false);
        sumaResultado.setVisible(false);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        labelResul = new javax.swing.JLabel();
        Num2 = new javax.swing.JTextField();
        Num1 = new javax.swing.JTextField();
        sumaResultado = new javax.swing.JTextField();
        btnCal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(500, 250));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowIconified(java.awt.event.WindowEvent evt) {
                formWindowIconified(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Suma de dos Enteros");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Numero 1");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Numero 2");

        labelResul.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        labelResul.setText("Resultado");

        Num2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Num2KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Num2KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Num2KeyTyped(evt);
            }
        });

        Num1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Num1ActionPerformed(evt);
            }
        });
        Num1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Num1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Num1KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Num1KeyTyped(evt);
            }
        });

        sumaResultado.setEditable(false);
        sumaResultado.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        sumaResultado.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btnCal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnCal.setEnabled(false);
        btnCal.setLabel("Calcular");
        btnCal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCalMouseClicked(evt);
            }
        });
        btnCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(Num1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Num2, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(33, 33, 33)))
                .addGap(33, 33, 33))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCal, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(labelResul))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sumaResultado, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(97, 97, 97))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Num1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Num2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(btnCal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(labelResul)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sumaResultado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>

    private void Num1ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }
    private boolean validarNum(String num) {
        try {
            if (num != null) {
                Integer.parseInt(num);
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }
    private double suma(){
        String num1 = Num1.getText();
        String num2 = Num2.getText();
        double suma = 0;
        if (!validarNum(num1) || !validarNum(num2)) {
            JOptionPane.showMessageDialog(null, "Solo debe ingresar numeros");
            suma = Double.POSITIVE_INFINITY;
        } else {
            suma = Integer.parseInt(Num1.getText()) + Integer.parseInt(Num2.getText()); 
        }
        return suma;
    }
    
    private void btnCalActionPerformed(java.awt.event.ActionEvent evt) {
        if(suma() != Double.POSITIVE_INFINITY){
            int resul = (int) suma();
            sumaResultado.setForeground(new java.awt.Color(0,0,0));
            labelResul.setVisible(true);
            sumaResultado.setVisible(true);
            sumaResultado.setText(String.valueOf(resul));
        }
    }

    private void Num1KeyTyped(java.awt.event.KeyEvent evt) {
  
    }

    private void Num1KeyReleased(java.awt.event.KeyEvent evt) {
        String num1 = Num1.getText();
        String num2 = Num2.getText();
        if (!num1.isEmpty() && !num2.isEmpty()) {
            btnCal.setEnabled(true);
        } else {
            btnCal.setEnabled(false);
        }
    }

    private void Num1KeyPressed(java.awt.event.KeyEvent evt) {
        if (evt.getKeyCode() == KeyEvent.VK_ENTER && btnCal.isEnabled()) {
           btnCal.doClick();
        } else if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Num2.requestFocus();
        }
    }

    private void formWindowIconified(java.awt.event.WindowEvent evt) {
        setVisible(false);
        trayApp t = new trayApp();
        t.Num1 = Integer.parseInt(Num1.getText());
        t.Num2 = Integer.parseInt(Num2.getText());
        t.Resul = Integer.parseInt(sumaResultado.getText());
    }

    private void Num2KeyTyped(java.awt.event.KeyEvent evt) {

    }

    private void Num2KeyReleased(java.awt.event.KeyEvent evt) {
        String num1 = Num1.getText();
        String num2 = Num2.getText();
        if (!num1.isEmpty() && !num2.isEmpty()) {
            btnCal.setEnabled(true);
        } else {
            btnCal.setEnabled(false);
        }
    }

    private void Num2KeyPressed(java.awt.event.KeyEvent evt) {
        if (evt.getKeyCode() == KeyEvent.VK_ENTER && btnCal.isEnabled()) {
            btnCal.doClick();
        } else if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Num1.requestFocus();
        }
    }

    private void btnCalMouseClicked(java.awt.event.MouseEvent evt) {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ejercicio3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify
    protected javax.swing.JTextField Num1;
    protected javax.swing.JTextField Num2;
    protected javax.swing.JButton btnCal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    protected javax.swing.JLabel labelResul;
    protected javax.swing.JTextField sumaResultado;
    // End of variables declaration
}
